clear all;
clc;
bellhop 'flatwav' 
plotray ('flatwav')  